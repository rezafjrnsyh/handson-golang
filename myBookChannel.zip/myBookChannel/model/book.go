package model

import "fmt"

type Book struct {
	bookId        string
	title         string
	pageNo        int
	cover         string
	yearPublished int
}

func NewEmptyBook() *Book {
	return &Book{}
}
func NewBook(bookId string, title string, pageNo int, cover string, yearPublished int) *Book {
	return &Book{
		bookId, title, pageNo, cover, yearPublished,
	}
}

func (b *Book) GetBookId() string {
	return b.bookId
}
func (b *Book) GetTitle() string {
	return b.title
}
func (b *Book) GetPageNo() int {
	return b.pageNo
}
func (b *Book) GetCover() string {
	return b.cover
}
func (b *Book) GetYearPublished() int {
	return b.yearPublished
}
func (b *Book) ToString() string {
	return fmt.Sprintf("Id:%s,Title:%s,Page No:%d,Cover:%s,Year:%d", b.bookId, b.title, b.pageNo, b.cover, b.yearPublished)
}
