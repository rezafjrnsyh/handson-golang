package service

import (
	"github.com/edwardsuwirya/bookChannel/model"
	"github.com/edwardsuwirya/bookChannel/repository"
	"sync"
)

const (
	AddBook = iota
	FindBook
)

type WorkRequest struct {
	Operation int
	Book      *model.Book
}
type WorkResponse struct {
	Wr      *WorkRequest
	Result  *model.Book
	Results []*model.Book
	Err     error
}

func Process(wr *WorkRequest, wg *sync.WaitGroup) *WorkResponse {
	resp := WorkResponse{Wr: wr}
	switch wr.Operation {
	case AddBook:
		repository.BookRepository = append(repository.BookRepository, wr.Book)
		resp.Result = wr.Book
	case FindBook:
		resp.Result = nil
		resp.Results = repository.BookRepository
	}
	wg.Done()
	return &resp
}
