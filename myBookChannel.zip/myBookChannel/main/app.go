package main

import (
	"fmt"
	"github.com/edwardsuwirya/bookChannel/model"
	"github.com/edwardsuwirya/bookChannel/repository"
	"github.com/edwardsuwirya/bookChannel/service"
	"strings"
	"sync"
)

var wg sync.WaitGroup

func main() {
	in := make(chan *service.WorkRequest)
	out := make(chan *service.WorkResponse)

	doneStatus := make(chan bool)

	go Processor(in, out, doneStatus)

	workRequests := []*service.WorkRequest{
		&service.WorkRequest{service.AddBook, model.NewBook("1", "Buku 1", 100, "Hard", 1990)},
		&service.WorkRequest{service.AddBook, model.NewBook("2", "Buku 2", 198, "Hard", 1987)},
		&service.WorkRequest{service.FindBook, nil},
	}

	for _, we := range workRequests {
		wg.Add(1)
		go func(we *service.WorkRequest) {
			in <- we
		}(we)

	}

	go func() {
		wg.Wait()
		doneStatus <- true
	}()
	for i := 0; i < len(workRequests); i++ {
		resp := <-out
		if resp.Result != nil {
			fmt.Printf("Result: %v, Error: %v\n", resp.Result.ToString(), resp.Err)
		}
	}

	fmt.Printf("%80s\n", strings.Repeat("=", 80))
	fmt.Printf("%-5s%-10s%-30s%-10s%-10s%-15s\n", "No", "ID", "Title", "Page#", "Cover", "Year")
	fmt.Printf("%80s\n", strings.Repeat("-", 80))
	for i, v := range repository.BookRepository {
		fmt.Printf("%-5d%-10s%-30s%-10d%-10s%-15d\n", i+1, v.GetBookId(), v.GetTitle(), v.GetPageNo(), v.GetCover(), v.GetYearPublished())
	}
	fmt.Printf("%80s\n", strings.Repeat("=", 80))
}

func Processor(in chan *service.WorkRequest, out chan *service.WorkResponse, doneStatus chan bool) {
	for {
		select {
		case <-doneStatus:
			break
		case wr := <-in:
			out <- service.Process(wr, &wg)
		}
	}
}
