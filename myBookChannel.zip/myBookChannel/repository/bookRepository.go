package repository

import "github.com/edwardsuwirya/bookChannel/model"

var BookRepository []*model.Book
